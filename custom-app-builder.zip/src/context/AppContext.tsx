import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Language, TaskItem, Transaction, TeamMember, NotificationItem } from '../types';
import { VIP_TIERS, INITIAL_NOTIFICATIONS, MOCK_TASKS_TEMPLATE } from '../data/mockData';
import { translations } from '../utils/translations';
import confetti from 'canvas-confetti';

interface AppContextType {
  user: User | null;
  language: Language;
  t: typeof translations.en;
  setLanguage: (lang: Language) => void;
  currentTab: 'home' | 'tasks' | 'team' | 'vip' | 'me';
  setCurrentTab: (tab: 'home' | 'tasks' | 'team' | 'vip' | 'me') => void;
  viewMode: 'mobile' | 'full';
  setViewMode: (mode: 'mobile' | 'full') => void;
  login: (email: string) => void;
  register: (email: string, inviteCode?: string) => void;
  logout: () => void;
  loginAsDemo: () => void;
  tasks: TaskItem[];
  completeTask: (taskId: string) => Promise<boolean>;
  upgradeVIP: (tierLevel: number) => { success: boolean; message: string };
  depositFunds: (amount: number, network?: string) => void;
  withdrawFunds: (amount: number, address: string, secPass: string) => { success: boolean; message: string };
  claimDailyReward: (day: number) => { success: boolean; reward: number };
  dailyClaimedDays: number[];
  luckySpin: () => { reward: number };
  spinAvailable: boolean;
  transactions: Transaction[];
  teamMembers: TeamMember[];
  notifications: NotificationItem[];
  unreadNotifsCount: number;
  markNotifsAsRead: () => void;
  activeModal: string | null;
  setActiveModal: (modal: string | null) => void;
  toastMessage: string | null;
  showToast: (msg: string) => void;
  taskResetSeconds: number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'porsche_platform_user_v1';
const LOCAL_STORAGE_TX = 'porsche_platform_tx_v1';
const LOCAL_STORAGE_TASKS = 'porsche_platform_tasks_v1';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('en');
  const [currentTab, setCurrentTab] = useState<'home' | 'tasks' | 'team' | 'vip' | 'me'>('home');
  const [viewMode, setViewMode] = useState<'mobile' | 'full'>('mobile');
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [dailyClaimedDays, setDailyClaimedDays] = useState<number[]>([1]);
  const [spinAvailable, setSpinAvailable] = useState<boolean>(true);
  const [taskResetSeconds, setTaskResetSeconds] = useState<number>(1024); // e.g. 00:17:04

  // User state
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    // Default demo user so the platform is immediately browsable as shown in screenshots
    return {
      id: 'po_889211',
      email: 'garykennedy911@gmail.com',
      vipLevel: 1,
      balance: 15.00,
      todayEarnings: 0.00,
      totalEarnings: 36.00,
      invitationCode: '167111',
      registeredAt: '2026-09-26 10:51:25',
      vipExpireAt: '2026-10-26 10:51:25',
      securityPassword: '******'
    };
  });

  // Transactions state
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_TX);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    return [
      {
        id: 'tx-001',
        type: 'deposit',
        amount: 50.00,
        status: 'completed',
        createdAt: '2026-09-26 10:45:10',
        txHash: '0x8f...e43c',
        network: 'USDT-TRC20',
      },
      {
        id: 'tx-002',
        type: 'task_reward',
        amount: 3.00,
        status: 'completed',
        createdAt: '2026-09-26 11:20:00',
        details: 'VIP1 Daily Tasks Batch 1',
      },
    ];
  });

  // Tasks state
  const [tasks, setTasks] = useState<TaskItem[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_TASKS);
      if (saved) return JSON.parse(saved);
    } catch {
      // fallback
    }
    const currentVip = user?.vipLevel || 1;
    const tier = VIP_TIERS.find(t => t.level === currentVip) || VIP_TIERS[0];
    return [
      {
        id: 'task-1',
        title: MOCK_TASKS_TEMPLATE[0].title,
        titleAr: MOCK_TASKS_TEMPLATE[0].titleAr,
        reward: tier.perTaskProfit,
        vipRequired: tier.level,
        completed: false,
        category: MOCK_TASKS_TEMPLATE[0].category,
        carModel: MOCK_TASKS_TEMPLATE[0].carModel,
      },
      {
        id: 'task-2',
        title: MOCK_TASKS_TEMPLATE[1].title,
        titleAr: MOCK_TASKS_TEMPLATE[1].titleAr,
        reward: tier.perTaskProfit,
        vipRequired: tier.level,
        completed: false,
        category: MOCK_TASKS_TEMPLATE[1].category,
        carModel: MOCK_TASKS_TEMPLATE[1].carModel,
      }
    ];
  });

  // Notifications
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  // Mock team members
  const [teamMembers] = useState<TeamMember[]>([
    {
      id: 'tm-1',
      email: 'alex.trader@gmail.com',
      level: 1,
      vipLevel: 2,
      depositAmount: 40.00,
      commissionEarned: 4.80,
      joinedAt: '2026-09-26 15:30',
    },
    {
      id: 'tm-2',
      email: 'khalid_invest@outlook.com',
      level: 1,
      vipLevel: 1,
      depositAmount: 15.00,
      commissionEarned: 1.80,
      joinedAt: '2026-09-26 18:20',
    },
    {
      id: 'tm-3',
      email: 'sara_crypto@gmail.com',
      level: 2,
      vipLevel: 3,
      depositAmount: 98.00,
      commissionEarned: 1.96,
      joinedAt: '2026-09-27 08:12',
    }
  ]);

  // Sync to local storage
  useEffect(() => {
    if (user) {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_TX, JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_TASKS, JSON.stringify(tasks));
  }, [tasks]);

  // Timer countdown
  useEffect(() => {
    const interval = setInterval(() => {
      setTaskResetSeconds(prev => (prev > 0 ? prev - 1 : 86400));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3200);
  };

  const login = (email: string) => {
    const newUser: User = {
      id: 'po_' + Math.floor(100000 + Math.random() * 900000),
      email: email || 'user@porsche-asset.com',
      vipLevel: 1,
      balance: 10.00,
      todayEarnings: 0.00,
      totalEarnings: 0.00,
      invitationCode: String(Math.floor(100000 + Math.random() * 900000)),
      registeredAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      vipExpireAt: new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString().replace('T', ' ').substring(0, 19),
      securityPassword: '******'
    };
    setUser(newUser);
    showToast(translations[language].welcome);
  };

  const register = (email: string, inviteCode?: string) => {
    const newUser: User = {
      id: 'po_' + Math.floor(100000 + Math.random() * 900000),
      email: email,
      vipLevel: 1,
      balance: 10.00,
      todayEarnings: 0.00,
      totalEarnings: 0.00,
      invitationCode: String(Math.floor(100000 + Math.random() * 900000)),
      inviterCode: inviteCode || '167111',
      registeredAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      vipExpireAt: new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString().replace('T', ' ').substring(0, 19),
      securityPassword: '******'
    };
    setUser(newUser);
    showToast(translations[language].welcome);
  };

  const logout = () => {
    setUser(null);
    showToast('Logged out');
  };

  const loginAsDemo = () => {
    const demo: User = {
      id: 'po_889211',
      email: 'garykennedy911@gmail.com',
      vipLevel: 1,
      balance: 45.00,
      todayEarnings: 1.50,
      totalEarnings: 36.00,
      invitationCode: '167111',
      registeredAt: '2026-09-26 10:51:25',
      vipExpireAt: '2026-10-26 10:51:25',
      securityPassword: '******'
    };
    setUser(demo);
    showToast(translations[language].welcome);
  };

  // Complete a task
  const completeTask = async (taskId: string): Promise<boolean> => {
    if (!user) return false;
    const task = tasks.find(t => t.id === taskId);
    if (!task || task.completed) return false;

    // Mark task completed
    const updatedTasks = tasks.map(t =>
      t.id === taskId ? { ...t, completed: true, completedAt: new Date().toLocaleTimeString() } : t
    );
    setTasks(updatedTasks);

    const reward = task.reward;
    setUser(prev => prev ? {
      ...prev,
      balance: +(prev.balance + reward).toFixed(2),
      todayEarnings: +(prev.todayEarnings + reward).toFixed(2),
      totalEarnings: +(prev.totalEarnings + reward).toFixed(2),
    } : null);

    // Record transaction
    const newTx: Transaction = {
      id: 'tx-' + Date.now(),
      type: 'task_reward',
      amount: reward,
      status: 'completed',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      details: task.title,
    };
    setTransactions(prev => [newTx, ...prev]);

    // Confetti effect
    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.7 }
      });
    } catch {
      // ignore
    }

    showToast(`+${reward.toFixed(2)} USDT earned!`);
    return true;
  };

  // Upgrade VIP
  const upgradeVIP = (tierLevel: number) => {
    if (!user) return { success: false, message: 'Please sign in first' };
    const tier = VIP_TIERS.find(t => t.level === tierLevel);
    if (!tier) return { success: false, message: 'Invalid VIP tier' };

    if (user.balance < tier.price) {
      return { success: false, message: translations[language].insufficientBalance };
    }

    setUser(prev => prev ? {
      ...prev,
      vipLevel: tier.level,
      balance: +(prev.balance - tier.price).toFixed(2),
      vipExpireAt: new Date(Date.now() + tier.daysValid * 24 * 3600 * 1000).toISOString().replace('T', ' ').substring(0, 19),
    } : null);

    // Refresh tasks for new VIP tier
    const newTasks: TaskItem[] = [
      {
        id: 'task-' + Date.now() + '-1',
        title: MOCK_TASKS_TEMPLATE[tier.level % MOCK_TASKS_TEMPLATE.length].title,
        titleAr: MOCK_TASKS_TEMPLATE[tier.level % MOCK_TASKS_TEMPLATE.length].titleAr,
        reward: tier.perTaskProfit,
        vipRequired: tier.level,
        completed: false,
        category: 'Porsche Fleet Telemetry',
        carModel: 'Porsche ' + tier.name,
      },
      {
        id: 'task-' + Date.now() + '-2',
        title: MOCK_TASKS_TEMPLATE[(tier.level + 1) % MOCK_TASKS_TEMPLATE.length].title,
        titleAr: MOCK_TASKS_TEMPLATE[(tier.level + 1) % MOCK_TASKS_TEMPLATE.length].titleAr,
        reward: tier.perTaskProfit,
        vipRequired: tier.level,
        completed: false,
        category: 'Porsche Powertrain Node',
        carModel: 'Porsche GT3 RS',
      }
    ];
    setTasks(newTasks);

    const newTx: Transaction = {
      id: 'tx-' + Date.now(),
      type: 'vip_purchase',
      amount: tier.price,
      status: 'completed',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      details: `Upgrade to ${tier.name}`,
    };
    setTransactions(prev => [newTx, ...prev]);

    try {
      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }

    return { success: true, message: translations[language].upgradeSuccess.replace('{tier}', tier.name) };
  };

  // Deposit
  const depositFunds = (amount: number, network = 'USDT-TRC20') => {
    if (!user) return;
    setUser(prev => prev ? {
      ...prev,
      balance: +(prev.balance + amount).toFixed(2),
    } : null);

    const newTx: Transaction = {
      id: 'tx-' + Date.now(),
      type: 'deposit',
      amount,
      status: 'completed',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      txHash: '0x' + Math.random().toString(16).substring(2, 10) + '...' + Math.random().toString(16).substring(2, 6),
      network,
    };
    setTransactions(prev => [newTx, ...prev]);
    showToast(translations[language].depositSuccess);
  };

  // Withdraw
  const withdrawFunds = (amount: number, address: string, secPass: string) => {
    if (!user) return { success: false, message: 'Please sign in' };
    if (amount < 3.0) return { success: false, message: translations[language].minWithdraw };
    if (amount > user.balance) return { success: false, message: 'Withdraw amount exceeds available balance' };
    if (!address || address.length < 10) return { success: false, message: 'Invalid wallet address' };
    if (!secPass) return { success: false, message: 'Please provide security password' };

    setUser(prev => prev ? {
      ...prev,
      balance: +(prev.balance - amount).toFixed(2),
    } : null);

    const newTx: Transaction = {
      id: 'tx-' + Date.now(),
      type: 'withdraw',
      amount,
      status: 'processing',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      txHash: address.substring(0, 6) + '...' + address.substring(address.length - 4),
      details: 'USDT-TRC20',
    };
    setTransactions(prev => [newTx, ...prev]);
    return { success: true, message: translations[language].withdrawSuccess };
  };

  // Daily Checkin
  const claimDailyReward = (day: number) => {
    if (dailyClaimedDays.includes(day)) {
      return { success: false, reward: 0 };
    }
    const reward = +(0.5 + day * 0.25).toFixed(2);
    setDailyClaimedDays(prev => [...prev, day]);

    setUser(prev => prev ? {
      ...prev,
      balance: +(prev.balance + reward).toFixed(2),
      todayEarnings: +(prev.todayEarnings + reward).toFixed(2),
    } : null);

    const newTx: Transaction = {
      id: 'tx-' + Date.now(),
      type: 'daily_reward',
      amount: reward,
      status: 'completed',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      details: `Day ${day} Daily Check-In Bonus`,
    };
    setTransactions(prev => [newTx, ...prev]);
    try {
      confetti({ particleCount: 50, spread: 50, origin: { y: 0.6 } });
    } catch {
      // ignore
    }
    return { success: true, reward };
  };

  // Lucky Spin
  const luckySpin = () => {
    const rewards = [1.00, 2.00, 5.00, 10.00, 0.50, 15.00];
    const reward = rewards[Math.floor(Math.random() * rewards.length)];
    setSpinAvailable(false);

    setUser(prev => prev ? {
      ...prev,
      balance: +(prev.balance + reward).toFixed(2),
      todayEarnings: +(prev.todayEarnings + reward).toFixed(2),
    } : null);

    const newTx: Transaction = {
      id: 'tx-' + Date.now(),
      type: 'daily_reward',
      amount: reward,
      status: 'completed',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      details: 'Lucky Gift Box Prize',
    };
    setTransactions(prev => [newTx, ...prev]);
    try {
      confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
    } catch {
      // ignore
    }
    return { reward };
  };

  const markNotifsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const unreadNotifsCount = notifications.filter(n => !n.read).length;

  return (
    <AppContext.Provider
      value={{
        user,
        language,
        t: translations[language],
        setLanguage,
        currentTab,
        setCurrentTab,
        viewMode,
        setViewMode,
        login,
        register,
        logout,
        loginAsDemo,
        tasks,
        completeTask,
        upgradeVIP,
        depositFunds,
        withdrawFunds,
        claimDailyReward,
        dailyClaimedDays,
        luckySpin,
        spinAvailable,
        transactions,
        teamMembers,
        notifications,
        unreadNotifsCount,
        markNotifsAsRead,
        activeModal,
        setActiveModal,
        toastMessage,
        showToast,
        taskResetSeconds,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
