import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { VIP_TIERS } from '../data/mockData';
import { VIPTier } from '../types';
import { Crown, Lock, CheckCircle2, Sparkles } from 'lucide-react';
import porscheCrestImg from '../assets/images/porsche_crest_badge_1790494625202.jpg';

export const VipView: React.FC = () => {
  const { user, t, upgradeVIP, setActiveModal, showToast } = useApp();
  const [selectedTier, setSelectedTier] = useState<VIPTier | null>(null);

  const currentVipLevel = user?.vipLevel || 1;

  const handleUnlock = (tier: VIPTier) => {
    setSelectedTier(tier);
  };

  const confirmUnlock = () => {
    if (!selectedTier) return;
    const res = upgradeVIP(selectedTier.level);
    showToast(res.message);
    if (!res.success) {
      // Prompt to deposit
      setActiveModal('deposit');
    }
    setSelectedTier(null);
  };

  return (
    <div className="pb-24 pt-2 px-3 max-w-md mx-auto space-y-3.5">
      {/* Top right "Upgrade Log" sub-header */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-semibold text-slate-300">
            Current Tier: <strong className="text-amber-400">VIP{currentVipLevel}</strong>
          </span>
        </div>
        <button
          onClick={() => setActiveModal('upgrade_log')}
          className="text-xs font-medium text-sky-400 hover:text-sky-300 underline underline-offset-2 transition-colors"
        >
          {t.upgradeLog}
        </button>
      </div>

      {/* VIP Tiers List */}
      <div className="space-y-3.5">
        {VIP_TIERS.map((tier) => {
          const isCurrentOrUnlocked = tier.level <= currentVipLevel;
          const isExactCurrent = tier.level === currentVipLevel;

          return (
            <div
              key={tier.level}
              className={`relative rounded-3xl p-4 transition-all overflow-hidden border ${
                isExactCurrent
                  ? 'bg-gradient-to-br from-[#1a3882] via-[#122c6b] to-[#0c1f52] border-blue-500/50 shadow-xl shadow-blue-900/30 ring-1 ring-blue-400/30'
                  : 'bg-gradient-to-br from-[#132a63]/90 via-[#0e2152]/90 to-[#09173d]/90 border-blue-900/40 shadow-md'
              }`}
            >
              {/* Top Banner Row: Badge + Status */}
              <div className="flex items-center justify-between mb-3">
                {/* Crown badge */}
                <div className="flex items-center gap-1 px-3 py-1 rounded-r-full -ml-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black text-xs shadow-md">
                  <Crown className="w-3.5 h-3.5 fill-slate-950 text-slate-950" />
                  <span>{tier.name}</span>
                </div>

                {/* Status or unlock label */}
                {isExactCurrent ? (
                  <div className="flex items-center gap-1 px-3 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{t.unlockValid}</span>
                  </div>
                ) : isCurrentOrUnlocked ? (
                  <div className="flex items-center gap-1 text-[11px] text-slate-400">
                    <Lock className="w-3 h-3 text-slate-400" />
                    <span>Unlocked</span>
                  </div>
                ) : null}
              </div>

              {/* Main Content: Left Crest, Right Stats */}
              <div className="grid grid-cols-[88px_1fr] gap-3 items-center">
                {/* Left: Porsche Logo */}
                <div className="flex flex-col items-center justify-center p-2 rounded-2xl bg-white shadow-md border border-slate-200">
                  <div className="w-12 h-14 relative flex items-center justify-center">
                    <img
                      src={porscheCrestImg}
                      alt="Porsche Crest"
                      className="w-full h-full object-contain"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <span className="text-[8px] font-black tracking-widest text-slate-900 mt-1 uppercase">
                    PORSCHE
                  </span>
                </div>

                {/* Right: Tier Statistics */}
                <div className="space-y-1 text-xs">
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400">{t.dailyTasks}</span>
                    <span className="font-semibold text-white font-mono">{tier.dailyTasks}</span>
                  </div>

                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400">{t.perTaskProfit}</span>
                    <span className="font-semibold text-emerald-400 font-mono">
                      {tier.perTaskProfit.toFixed(2)}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400">{t.dailyProfit}</span>
                    <span className="font-semibold text-sky-400 font-mono">
                      {tier.dailyProfit.toFixed(2)} USDT
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400">{t.totalProfit}</span>
                    <span className="font-semibold text-amber-400 font-mono">
                      {tier.totalProfit.toLocaleString()}.00 USDT
                    </span>
                  </div>
                </div>
              </div>

              {/* Card Footer: Either Effective Time or Unlock Button */}
              {isExactCurrent ? (
                <div className="mt-3 pt-2.5 border-t border-blue-800/40 text-[10px] text-sky-300 font-mono flex items-center justify-between">
                  <span>{t.effectiveTime}:</span>
                  <span>{user?.registeredAt} - {user?.vipExpireAt}</span>
                </div>
              ) : !isCurrentOrUnlocked ? (
                <div className="mt-3 pt-2 flex justify-end">
                  <button
                    onClick={() => handleUnlock(tier)}
                    className="w-full sm:w-auto px-6 py-2.5 rounded-full bg-slate-950 hover:bg-black active:scale-98 text-white text-xs font-bold border border-blue-600/40 shadow-lg flex items-center justify-center gap-2 transition-all"
                  >
                    <span className="font-mono text-amber-400">{tier.price.toFixed(2)} USDT</span>
                    <span>{t.unlockNow}</span>
                  </button>
                </div>
              ) : null}
            </div>
          );
        })}
      </div>

      {/* Confirmation Modal for VIP Unlock */}
      {selectedTier && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm bg-gradient-to-b from-[#122b6b] to-[#08173d] border border-blue-500/40 rounded-3xl p-5 shadow-2xl text-white">
            <div className="flex items-center gap-2 mb-3">
              <Crown className="w-5 h-5 text-amber-400" />
              <h3 className="text-base font-bold">{t.unlockConfirmTitle}</h3>
            </div>

            <p className="text-xs text-blue-200/90 mb-4 leading-relaxed">
              {t.unlockConfirmDesc
                .replace('{tier}', selectedTier.name)
                .replace('{price}', selectedTier.price.toFixed(2))}
            </p>

            <div className="bg-[#071333] p-3 rounded-2xl border border-blue-900/50 mb-5 space-y-1.5 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Available Balance:</span>
                <span className="font-mono font-bold text-white">
                  {user?.balance.toFixed(2)} USDT
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Unlock Fee:</span>
                <span className="font-mono font-bold text-amber-400">
                  {selectedTier.price.toFixed(2)} USDT
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Daily Profit:</span>
                <span className="font-mono font-bold text-emerald-400">
                  {selectedTier.dailyProfit.toFixed(2)} USDT / day
                </span>
              </div>
            </div>

            <div className="flex gap-2.5">
              <button
                onClick={() => setSelectedTier(null)}
                className="flex-1 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-slate-300 transition-colors"
              >
                {t.cancel}
              </button>
              <button
                onClick={confirmUnlock}
                className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-blue-500 to-sky-500 hover:from-blue-600 text-xs font-bold text-white shadow-lg shadow-blue-500/30 transition-all"
              >
                {t.confirm}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
