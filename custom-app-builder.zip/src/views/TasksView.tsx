import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Clock, CheckCircle2, ChevronRight, Zap, Car } from 'lucide-react';
import luxuryCarImg from '../assets/images/luxury_gt_car_1790494637307.jpg';

export const TasksView: React.FC = () => {
  const { t, language, tasks, completeTask, taskResetSeconds } = useApp();
  const [activeTab, setActiveTab] = useState<'in_progress' | 'completed'>('in_progress');
  const [processingTaskId, setProcessingTaskId] = useState<string | null>(null);

  // Format seconds into HH:MM:SS
  const formatTimer = (totalSec: number) => {
    const hours = Math.floor(totalSec / 3600);
    const minutes = Math.floor((totalSec % 3600) / 60);
    const seconds = totalSec % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes
      .toString()
      .padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  const inProgressTasks = tasks.filter((t) => !t.completed);
  const completedTasks = tasks.filter((t) => t.completed);

  const handleFinish = async (taskId: string) => {
    setProcessingTaskId(taskId);
    // Simulate real order telemetry consensus delay
    setTimeout(async () => {
      await completeTask(taskId);
      setProcessingTaskId(null);
    }, 1200);
  };

  return (
    <div className="pb-24 pt-2 px-3 max-w-md mx-auto space-y-4">
      {/* Top Cyan/Blue Gradient Card (exact match from screenshot 5) */}
      <div className="relative rounded-3xl p-5 bg-gradient-to-r from-[#7a88ff] via-[#48b5f3] to-[#2bd9c6] text-slate-900 shadow-xl overflow-hidden">
        {/* Task Reset Pill */}
        <div className="flex justify-center mb-4">
          <div className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-black/85 text-white text-xs font-mono font-semibold shadow-md">
            <Clock className="w-3.5 h-3.5 text-sky-400" />
            <span className="text-slate-300">{t.taskReset}</span>
            <span className="text-white font-bold">{formatTimer(taskResetSeconds)}</span>
          </div>
        </div>

        {/* Counters */}
        <div className="grid grid-cols-2 text-center">
          <div className="border-r border-slate-900/15 pr-2">
            <div className="text-xs font-bold text-slate-900 mb-1">{t.todaysTasks}</div>
            <div className="text-2xl font-black font-mono text-slate-950">{tasks.length}</div>
          </div>
          <div className="pl-2">
            <div className="text-xs font-bold text-slate-900 mb-1">{t.tasksRemainingToday}</div>
            <div className="text-2xl font-black font-mono text-slate-950">
              {inProgressTasks.length}
            </div>
          </div>
        </div>
      </div>

      {/* Main Container Card */}
      <div className="bg-[#0b1c47]/80 border border-blue-900/40 rounded-3xl p-4 shadow-xl min-h-[380px] flex flex-col">
        {/* Segmented Tab Bar (exact match screenshot 5: "In Progress" | "Completed") */}
        <div className="flex bg-[#071333] p-1 rounded-2xl mb-4 border border-blue-950 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('in_progress')}
            className={`flex-1 py-2.5 rounded-xl font-semibold transition-all ${
              activeTab === 'in_progress'
                ? 'bg-blue-600/70 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.inProgress}
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('completed')}
            className={`flex-1 py-2.5 rounded-xl font-semibold transition-all ${
              activeTab === 'completed'
                ? 'bg-blue-600/70 text-white shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.completed}
          </button>
        </div>

        {/* Tab Content */}
        <div className="flex-1 flex flex-col">
          {activeTab === 'in_progress' && (
            <>
              {inProgressTasks.length === 0 ? (
                /* "No data" state matching Screenshot 5 exactly */
                <div className="flex-1 flex flex-col items-center justify-center py-16 text-center text-slate-400">
                  <div className="w-16 h-16 rounded-full bg-blue-900/20 border border-blue-800/30 flex items-center justify-center mb-3">
                    <CheckCircle2 className="w-8 h-8 text-blue-400/60" />
                  </div>
                  <span className="text-sm font-medium text-slate-400">{t.noData}</span>
                  <p className="text-xs text-slate-500 mt-1 max-w-xs px-4">
                    {t.allTasksCompletedToday} {formatTimer(taskResetSeconds)}
                  </p>
                </div>
              ) : (
                /* Available Tasks to complete */
                <div className="space-y-3">
                  {inProgressTasks.map((task) => (
                    <div
                      key={task.id}
                      className="bg-gradient-to-br from-[#12285e] to-[#0a183b] border border-blue-700/40 rounded-2xl p-3.5 shadow-lg flex flex-col gap-2.5 relative overflow-hidden"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <div className="w-9 h-9 rounded-xl bg-blue-500/20 border border-blue-400/30 flex items-center justify-center shrink-0">
                            <Car className="w-5 h-5 text-sky-400" />
                          </div>
                          <div>
                            <span className="text-[10px] font-mono uppercase text-sky-300 font-semibold">
                              {task.category}
                            </span>
                            <h4 className="text-xs font-bold text-white line-clamp-1">
                              {language === 'ar' ? task.titleAr : task.title}
                            </h4>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <span className="text-[10px] text-slate-400 block">Reward</span>
                          <span className="text-xs font-mono font-bold text-emerald-400">
                            +{task.reward.toFixed(2)} USDT
                          </span>
                        </div>
                      </div>

                      {/* Car Asset Preview Banner */}
                      <div className="relative h-20 w-full rounded-xl overflow-hidden border border-blue-950">
                        <img
                          src={luxuryCarImg}
                          alt={task.carModel}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/80 via-transparent to-transparent flex items-center px-3">
                          <span className="text-[11px] font-bold text-white bg-blue-600/80 px-2 py-0.5 rounded-md backdrop-blur-sm">
                            {task.carModel}
                          </span>
                        </div>
                      </div>

                      {/* Action Button */}
                      <button
                        disabled={processingTaskId === task.id}
                        onClick={() => handleFinish(task.id)}
                        className={`w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md ${
                          processingTaskId === task.id
                            ? 'bg-blue-600/50 text-white cursor-wait'
                            : 'bg-gradient-to-r from-blue-500 to-sky-500 hover:from-blue-600 text-white active:scale-98 shadow-blue-500/30'
                        }`}
                      >
                        {processingTaskId === task.id ? (
                          <>
                            <Zap className="w-3.5 h-3.5 animate-spin" />
                            <span>{t.processingTask}</span>
                          </>
                        ) : (
                          <>
                            <span>{t.doTask}</span>
                            <ChevronRight className="w-4 h-4" />
                          </>
                        )}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {activeTab === 'completed' && (
            <div className="space-y-2.5">
              {completedTasks.length === 0 ? (
                <div className="flex-1 flex flex-col items-center justify-center py-16 text-center text-slate-400">
                  <span className="text-sm font-medium">{t.noData}</span>
                </div>
              ) : (
                completedTasks.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-center justify-between p-3 rounded-2xl bg-[#091738]/80 border border-blue-900/30 text-xs"
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div>
                        <h5 className="font-bold text-white text-[11px] line-clamp-1">
                          {language === 'ar' ? task.titleAr : task.title}
                        </h5>
                        <span className="text-[10px] text-slate-400">
                          {task.completedAt || 'Today'}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="font-mono font-bold text-emerald-400 text-xs">
                        +{task.reward.toFixed(2)} USDT
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
