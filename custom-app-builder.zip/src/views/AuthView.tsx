import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PorscheLogo } from '../components/PorscheLogo';
import { Eye, EyeOff, Globe, Send, ChevronDown } from 'lucide-react';

export const AuthView: React.FC = () => {
  const { login, register, loginAsDemo, t, language, setLanguage, setActiveModal } = useApp();
  const [isSignUp, setIsSignUp] = useState(false);
  const [method, setMethod] = useState<'email' | 'phone'>('email');
  
  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [password, setPassword] = useState('');
  const [rePassword, setRePassword] = useState('');
  const [inviteCode, setInviteCode] = useState('167111');
  const [showPassword, setShowPassword] = useState(false);
  const [showRePassword, setShowRePassword] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!emailOrPhone) {
      setErrorMsg(method === 'email' ? 'Please enter email' : 'Please enter phone number');
      return;
    }
    if (!password) {
      setErrorMsg('Please enter password');
      return;
    }

    if (isSignUp) {
      if (password !== rePassword) {
        setErrorMsg('Passwords do not match');
        return;
      }
      register(emailOrPhone, inviteCode);
    } else {
      login(emailOrPhone);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#082057] via-[#051740] to-[#020b22] text-white flex flex-col justify-between p-4 relative overflow-hidden font-sans">
      {/* Background ambient gradient glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[500px] bg-blue-600/20 rounded-full blur-[120px] pointer-events-none" />

      {/* Top language selector */}
      <div className="relative flex justify-end z-20 pt-2">
        <button
          onClick={() => setLangOpen(!langOpen)}
          className="flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded-full bg-white/10 hover:bg-white/20 border border-white/15 text-white shadow-sm"
        >
          <Globe className="w-3.5 h-3.5" />
          <span>{language === 'en' ? 'English' : 'العربية'}</span>
          <ChevronDown className="w-3 h-3 text-white/70" />
        </button>

        {langOpen && (
          <div className="absolute right-0 top-9 w-32 bg-slate-900 border border-blue-600/40 rounded-xl shadow-2xl py-1 z-50 text-xs">
            <button
              onClick={() => {
                setLanguage('en');
                setLangOpen(false);
              }}
              className="w-full text-left px-3 py-2 hover:bg-blue-600/20 text-slate-200"
            >
              English
            </button>
            <button
              onClick={() => {
                setLanguage('ar');
                setLangOpen(false);
              }}
              className="w-full text-right px-3 py-2 hover:bg-blue-600/20 text-slate-200"
            >
              العربية
            </button>
          </div>
        )}
      </div>

      {/* Center content */}
      <div className="flex-1 flex flex-col items-center justify-center max-w-sm mx-auto w-full z-10 py-6">
        {/* Brand Crest */}
        <PorscheLogo size="lg" showText={true} className="mb-2" />

        {/* Title */}
        <h1 className="text-2xl font-bold tracking-tight text-white mt-1">
          {t.appName}
        </h1>
        <p className="text-sm text-blue-200/80 mb-6">
          {t.welcome}
        </p>

        {/* Main Glass Form Card */}
        <div className="w-full bg-[#112457]/70 backdrop-blur-xl border border-blue-500/20 rounded-3xl p-5 shadow-2xl relative">
          {/* Floating telegram button on right */}
          <button
            onClick={() => setActiveModal('telegram')}
            className="absolute top-14 -right-3 w-10 h-10 rounded-full bg-sky-500 text-white flex items-center justify-center shadow-lg shadow-sky-500/40 hover:scale-105 active:scale-95 transition-all border border-white/20"
          >
            <Send className="w-4 h-4 -rotate-12 translate-x-[-1px]" />
          </button>

          {/* Segmented Tab Bar */}
          <div className="flex bg-[#0b173a]/80 p-1 rounded-2xl mb-5 border border-blue-900/40 text-xs">
            <button
              type="button"
              onClick={() => setMethod('email')}
              className={`flex-1 py-2.5 rounded-xl font-medium transition-all ${
                method === 'email'
                  ? 'bg-blue-600/80 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {isSignUp ? t.signUpWithEmail : t.signInWithEmail}
            </button>
            <button
              type="button"
              onClick={() => setMethod('phone')}
              className={`flex-1 py-2.5 rounded-xl font-medium transition-all ${
                method === 'phone'
                  ? 'bg-blue-600/80 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {isSignUp ? t.signUpWithPhone : t.signInWithPhone}
            </button>
          </div>

          {errorMsg && (
            <div className="mb-4 p-2.5 bg-red-500/20 border border-red-500/40 rounded-xl text-xs text-red-200 text-center">
              {errorMsg}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email or Phone field */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                {method === 'email' ? t.email : t.phone}
              </label>
              <input
                type={method === 'email' ? 'email' : 'tel'}
                value={emailOrPhone}
                onChange={(e) => setEmailOrPhone(e.target.value)}
                placeholder={method === 'email' ? t.email : t.phone}
                className="w-full px-4 py-3 bg-[#0d1d45]/90 border border-blue-900/60 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                {t.password}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={t.password}
                  className="w-full px-4 py-3 bg-[#0d1d45]/90 border border-blue-900/60 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4 text-slate-400" />}
                </button>
              </div>
            </div>

            {/* Re-enter Password for Sign Up */}
            {isSignUp && (
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  {t.reEnterPassword}
                </label>
                <div className="relative">
                  <input
                    type={showRePassword ? 'text' : 'password'}
                    value={rePassword}
                    onChange={(e) => setRePassword(e.target.value)}
                    placeholder={t.reEnterPassword}
                    className="w-full px-4 py-3 bg-[#0d1d45]/90 border border-blue-900/60 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowRePassword(!showRePassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showRePassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4 text-slate-400" />}
                  </button>
                </div>
              </div>
            )}

            {/* Invitation Code for Sign Up */}
            {isSignUp && (
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  {t.invitationCode}
                </label>
                <input
                  type="text"
                  value={inviteCode}
                  onChange={(e) => setInviteCode(e.target.value)}
                  placeholder={t.invitationCode}
                  className="w-full px-4 py-3 bg-[#0d1d45]/90 border border-blue-900/60 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all font-mono"
                />
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full mt-4 py-3.5 px-4 bg-gradient-to-r from-blue-500 to-sky-500 hover:from-blue-600 hover:to-sky-600 text-white font-semibold rounded-2xl shadow-lg shadow-blue-500/30 active:scale-[0.99] transition-all text-sm"
            >
              {isSignUp ? t.signUp : t.signIn}
            </button>
          </form>

          {/* Switch between Sign In and Sign Up */}
          <div className="mt-5 text-center">
            <button
              type="button"
              onClick={() => {
                setIsSignUp(!isSignUp);
                setErrorMsg('');
              }}
              className="text-xs font-medium text-blue-300 hover:text-white transition-colors"
            >
              {isSignUp ? t.alreadyHaveAccount + ' ' + t.signIn : t.noAccount + ' ' + t.signUp}
            </button>
          </div>
        </div>

        {/* Instant Demo Quick Access */}
        <button
          onClick={loginAsDemo}
          className="mt-4 px-4 py-2 text-xs text-blue-300/80 hover:text-blue-200 border border-blue-500/20 rounded-full hover:bg-blue-900/20 transition-all"
        >
          ⚡ {t.orExploreDemo}
        </button>
      </div>

      {/* Footer copyright */}
      <footer className="text-center text-[10px] text-slate-500 py-2">
        © 2026 Porsche Global Asset Platform. All rights reserved.
      </footer>
    </div>
  );
};
