import { VIPTier, TaskItem, NotificationItem } from '../types';

export const VIP_TIERS: VIPTier[] = [
  {
    level: 1,
    name: 'VIP1',
    price: 0,
    dailyTasks: 2,
    perTaskProfit: 1.50,
    dailyProfit: 3.00,
    totalProfit: 90.00,
    daysValid: 30,
  },
  {
    level: 2,
    name: 'VIP2',
    price: 40.00,
    dailyTasks: 2,
    perTaskProfit: 10.00,
    dailyProfit: 20.00,
    totalProfit: 600.00,
    daysValid: 30,
  },
  {
    level: 3,
    name: 'VIP3',
    price: 98.00,
    dailyTasks: 2,
    perTaskProfit: 24.50,
    dailyProfit: 49.00,
    totalProfit: 1470.00,
    daysValid: 30,
  },
  {
    level: 4,
    name: 'VIP4',
    price: 280.00,
    dailyTasks: 2,
    perTaskProfit: 75.00,
    dailyProfit: 150.00,
    totalProfit: 4500.00,
    daysValid: 30,
  },
  {
    level: 5,
    name: 'VIP5',
    price: 680.00,
    dailyTasks: 2,
    perTaskProfit: 190.00,
    dailyProfit: 380.00,
    totalProfit: 11400.00,
    daysValid: 30,
  },
  {
    level: 6,
    name: 'VIP6',
    price: 1680.00,
    dailyTasks: 2,
    perTaskProfit: 480.00,
    dailyProfit: 960.00,
    totalProfit: 28800.00,
    daysValid: 30,
  },
  {
    level: 7,
    name: 'VIP7',
    price: 3680.00,
    dailyTasks: 2,
    perTaskProfit: 1080.00,
    dailyProfit: 2160.00,
    totalProfit: 64800.00,
    daysValid: 30,
  },
  {
    level: 8,
    name: 'VIP8',
    price: 8880.00,
    dailyTasks: 2,
    perTaskProfit: 2700.00,
    dailyProfit: 5400.00,
    totalProfit: 162000.00,
    daysValid: 30,
  }
];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    title: 'Porsche Asset Collaboration Platform Launch',
    titleAr: 'إطلاق منصة بورش العالمية للتعاون الاستثماري',
    content: 'Welcome to Porsche Global Asset Platform. Complete daily telemetry and valuation tasks to receive real-time USDT commissions.',
    contentAr: 'أهلاً بك في منصة بورش العالمية للأصول المشفرة. قم بإنجاز المهام اليومية لتلقي أرباح USDT الفورية.',
    time: '2026-09-27 10:00',
    read: false,
  },
  {
    id: 'notif-2',
    title: 'VIP Reward System Online',
    titleAr: 'نظام مكافآت VIP يعمل بنجاح',
    content: 'Upgrade to VIP2 or VIP3 to enjoy higher daily commission returns up to 1,470 USDT monthly.',
    contentAr: 'قم بالترقية إلى VIP2 أو VIP3 للاستمتاع بعوائد يومية أعلى تصل إلى 1,470 USDT شهرياً.',
    time: '2026-09-26 14:30',
    read: false,
  },
  {
    id: 'notif-3',
    title: 'Daily Task Refresh Time',
    titleAr: 'موعد تحديث المهام اليومية',
    content: 'All tasks reset automatically every day at 00:00 UTC. Ensure you claim your daily task rewards.',
    contentAr: 'يتم تحديث جميع المهام تلقائياً كل يوم عند الساعة 00:00 UTC. احرص على إنهاء مهامك اليومية.',
    time: '2026-09-25 09:15',
    read: true,
  }
];

export const MOCK_TASKS_TEMPLATE: Omit<TaskItem, 'id' | 'completed' | 'reward'>[] = [
  {
    title: 'Porsche 911 GT3 RS Telemetry Asset Verification',
    titleAr: 'التحقق من بيانات القياس لسيارة بورش 911 GT3 RS',
    vipRequired: 1,
    category: 'Automotive Verification',
    carModel: '911 GT3 RS',
  },
  {
    title: 'Taycan Turbo S Electric Battery Health Consensus',
    titleAr: 'تقييم كفاءة بطارية تايكان توربو S الكهربائية',
    vipRequired: 1,
    category: 'Green Fleet Order',
    carModel: 'Taycan Turbo S',
  },
  {
    title: 'Panamera GTS Executive Performance Audit',
    titleAr: 'تدقيق أداء محرك بورش باناميرا GTS التنفيذية',
    vipRequired: 2,
    category: 'Executive Luxury Order',
    carModel: 'Panamera GTS',
  },
  {
    title: 'Cayenne Turbo GT Dynamic Powertrain Benchmark',
    titleAr: 'معايرة القوة الديناميكية لبورش كايين توربو GT',
    vipRequired: 2,
    category: 'SUV High Performance',
    carModel: 'Cayenne Turbo GT',
  },
  {
    title: 'Porsche 718 Cayman GT4 RS Aerodynamic Task',
    titleAr: 'مهمة فحص الديناميكا الهوائية لبورش 718 كايمان GT4 RS',
    vipRequired: 3,
    category: 'Aerodynamic Stream',
    carModel: '718 Cayman GT4 RS',
  },
  {
    title: 'Porsche 918 Spyder Hybrid Powertrain Node Valuation',
    titleAr: 'تقييم منظومة الهايبرد لسيارة بورش 918 سبايدر النادرة',
    vipRequired: 3,
    category: 'Hypercar Validation',
    carModel: '918 Spyder',
  }
];

export const MOCK_LIVE_WITHDRAWALS = [
  { user: 'po_***892', amount: '120.00 USDT', time: '1 min ago' },
  { user: 'po_***314', amount: '49.00 USDT', time: '3 mins ago' },
  { user: 'po_***901', amount: '350.00 USDT', time: '5 mins ago' },
  { user: 'po_***627', amount: '20.00 USDT', time: '8 mins ago' },
  { user: 'po_***115', amount: '1,470.00 USDT', time: '12 mins ago' },
  { user: 'po_***489', amount: '98.00 USDT', time: '14 mins ago' },
];
