import React from 'react';
import porscheCrestImg from '../assets/images/porsche_crest_badge_1790494625202.jpg';

interface PorscheLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  className?: string;
}

export const PorscheLogo: React.FC<PorscheLogoProps> = ({
  size = 'md',
  showText = true,
  className = '',
}) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-14 h-14',
    lg: 'w-20 h-20',
  };

  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      <div
        className={`${sizeClasses[size]} rounded-full bg-white p-1 flex items-center justify-center shadow-lg border-2 border-amber-400/40 overflow-hidden relative`}
      >
        <img
          src={porscheCrestImg}
          alt="Porsche Emblem"
          className="w-full h-full object-contain"
          referrerPolicy="no-referrer"
          onError={(e) => {
            // High-res SVG fallback of the classic gold/red/black crest
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
        {/* Fallback stylized crest if image ever fails */}
        <div className="absolute inset-0 bg-gradient-to-b from-amber-500/20 to-black/40 pointer-events-none" />
      </div>
      {showText && (
        <span className="text-[10px] tracking-[0.25em] font-black text-white/90 mt-1 uppercase">
          PORSCHE
        </span>
      )}
    </div>
  );
};
